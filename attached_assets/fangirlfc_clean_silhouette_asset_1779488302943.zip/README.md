# Fangirl FC — Clean Footballer Silhouette Asset

Recommended file for Replit integration:
`fut_player_silhouette_clean_transparent.png`

Alternative:
`fut_player_silhouette_clean_wrapper.svg` embeds the transparent PNG in an SVG wrapper with a stable viewBox.

## Dimensions

Cropped transparent PNG:
- width: 1046px
- height: 1279px
- ratio: 0.817826

Full-size transparent PNG:
- same canvas as the generated source image

## Notes

This asset was extracted from the provided generated silhouette image.
The checkerboard background was removed.
The output has transparent background and near-black silhouette fill.

For the current card creator, use the PNG asset first. It is visually closer to the reference app than the previous generic SVG placeholder.

Suggested integration:
- store in `public/assets/player-silhouettes/fut_player_silhouette_clean_transparent.png`
- use this as no-photo silhouette
- no Konva clip Group in no-photo mode
- opacity start: 0.68 to 0.78
- separate silhouette box from uploaded photo box
